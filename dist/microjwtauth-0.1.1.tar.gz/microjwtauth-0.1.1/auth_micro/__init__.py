# coding: utf-8
__title__ = 'microjwtauth'
__version__ = '0.1.1'
__author__ = 'ivan'
__license__ = 'BSD 2-Clause'
__copyright__ = 'Copyright 2019-2025 ivan'

# Version synonym
VERSION = __version__

